package application.model;

public class MVCPlanner {
	
}
