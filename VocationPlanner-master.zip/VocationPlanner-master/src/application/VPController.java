//Authors:	name				GitHub usr
//			William Wells		wiwells
//			Samuel Pilato		sampleauto
//			Jacob Forney		jakexclone
//			Ravinder Chaupain	vnm303
//			Jasmine Beale		jnbeale
//Class: Application Programming 3443
//Section: 001
//Date Created: 4/19/2021

package application;

import application.model.MVCPlanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;


public class VPController {
	
    @FXML
    void transportation(ActionEvent event) {
    	
    }

    @FXML
    void location(ActionEvent event) {

    }

    @FXML
    void checklist(ActionEvent event) {

    }

    @FXML
    void activities(ActionEvent event) {

    }
}
